let saves = 0;
function saveData() { saves++; }
let arr = [1, 2];
const proxy = new Proxy(arr, {
  set(target, prop, value) {
    target[prop] = value;
    saveData();
    return true;
  }
});
proxy.unshift(0);
console.log(arr, saves);
