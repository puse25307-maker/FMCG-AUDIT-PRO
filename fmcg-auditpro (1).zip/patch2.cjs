const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const replacement = `
// --- PERSISTENT DATABASE ---
const DATA_FILE = path.join(process.cwd(), 'data.json');

let db: {
  inspections: any[];
  reports: any[];
  notifications: AppNotification[];
} = {
  inspections: [],
  reports: [],
  notifications: []
};

if (fs.existsSync(DATA_FILE)) {
  try {
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    db = { ...db, ...parsed };
    if (!db.inspections) db.inspections = [];
    if (!db.reports) db.reports = [];
    if (!db.notifications) db.notifications = [];
  } catch (err) {
    console.error("Error reading data.json:", err);
  }
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error("Error saving data.json:", err);
  }
}

// Proxy arrays so existing code (push/unshift) automatically triggers saveData
const createProxy = <T extends any[]>(arr: T): T => {
  return new Proxy(arr, {
    set(target, prop, value) {
      target[Number(prop) || prop as any] = value;
      saveData();
      return true;
    }
  });
};

let inspections = createProxy(db.inspections);
let reports = createProxy(db.reports);
`;

content = content.replace(/\/\/ --- PERSISTENT DATABASE ---[\s\S]*?let reports = createProxy\(db\.reports, 'reports'\);/, replacement);

content = content.replace(/let notifications = createProxy\(db\.notifications, 'notifications'\);/, "let notifications = createProxy(db.notifications);");

fs.writeFileSync('server.ts', content);
