import { ExtractedData, RuleEvaluation } from "./src/types";

export interface RegulatoryRule {
  ruleId: string;
  requirement: string;
  requiredFields: (keyof ExtractedData)[];
  applicability: (category: string) => boolean;
  source: string;
}

export const LMPC_RULES: RegulatoryRule[] = [
  {
    ruleId: "LMPC-001",
    requirement: "Manufacturer, Packer, or Importer Details",
    requiredFields: ["manufacturerDetails", "packerDetails", "importerDetails"],
    applicability: () => true, // Applies to all packaged commodities
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
  {
    ruleId: "LMPC-002",
    requirement: "Country of Origin",
    requiredFields: ["countryOfOrigin"],
    applicability: () => true,
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
  {
    ruleId: "LMPC-003",
    requirement: "Common or Generic Name",
    requiredFields: ["commonGenericName"],
    applicability: () => true,
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
  {
    ruleId: "LMPC-004",
    requirement: "Net Quantity",
    requiredFields: ["netQuantity"],
    applicability: () => true,
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
  {
    ruleId: "LMPC-005",
    requirement: "Maximum Retail Price (MRP)",
    requiredFields: ["mrp"],
    applicability: () => true,
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
  {
    ruleId: "LMPC-006",
    requirement: "Date of Manufacture / Packing / Import",
    requiredFields: ["manufacturingDate", "packingDate"],
    applicability: () => true,
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
  {
    ruleId: "LMPC-007",
    requirement: "Best Before / Use By",
    requiredFields: ["bestBefore", "useBy"],
    applicability: (category) => category === "FOOD" || category === "COSMETICS_PERSONAL_CARE" || category === "BEVERAGE",
    source: "Legal Metrology (Packaged Commodities) Rules, 2011 / FSSAI Labelling",
  },
  {
    ruleId: "LMPC-008",
    requirement: "Consumer Care Details",
    requiredFields: ["consumerCare"],
    applicability: () => true,
    source: "Legal Metrology (Packaged Commodities) Rules, 2011",
  },
];

export interface NormalizedEvidence {
  field: string;
  rawEvidence: string | null;
  normalizedValue: string | null;
  visibility: "VISIBLE" | "NOT_VISIBLE" | "UNCERTAIN";
  confidence: number;
  evidenceStatus: "FOUND" | "NOT_FOUND" | "UNCERTAIN";
}

export class RuleEngine {
  static getApplicableRegulations(category: string): string[] {
    const regs = ["Legal Metrology (Packaged Commodities) Rules, 2011"];
    if (category === "FOOD" || category === "BEVERAGE") {
      regs.push("FSSAI (Food Safety and Standards) Packaging and Labelling Regulations");
    } else if (category === "COSMETICS_PERSONAL_CARE") {
      regs.push("Cosmetics Rules, 2020");
    }
    return regs;
  }

  static normalizeEvidence(extractedData: ExtractedData, rule: RegulatoryRule): NormalizedEvidence {
    for (const fieldName of rule.requiredFields) {
      const field = extractedData[fieldName];
      if (field && field.present) {
        return {
          field: String(fieldName),
          rawEvidence: field.evidence || String(field.value) || null,
          normalizedValue: field.normalizedValue ? String(field.normalizedValue) : (field.value ? String(field.value) : null),
          visibility: "VISIBLE",
          confidence: field.confidence || 0,
          evidenceStatus: "FOUND"
        };
      }
    }
    return {
      field: String(rule.requiredFields[0]),
      rawEvidence: null,
      normalizedValue: null,
      visibility: "NOT_VISIBLE",
      confidence: 0,
      evidenceStatus: "NOT_FOUND"
    };
  }

  static evaluate(
    extractedData: ExtractedData,
    category: string,
    imageQuality: string
  ): RuleEvaluation[] {
    const evaluations: RuleEvaluation[] = [];

    for (const rule of LMPC_RULES) {
      if (!rule.applicability(category)) {
        evaluations.push({
          ruleId: rule.ruleId,
          requirement: rule.requirement,
          status: 'NOT_APPLICABLE',
          evidence: null,
          confidence: 1,
          source: rule.source,
          explanation: "This requirement does not apply to the identified product category.",
        });
        continue;
      }

      const canonicalEvidence = this.normalizeEvidence(extractedData, rule);

      if (canonicalEvidence.evidenceStatus !== "FOUND") {
        evaluations.push({
          ruleId: rule.ruleId,
          requirement: rule.requirement,
          status: 'REVIEW_REQUIRED',
          evidence: null,
          confidence: 0,
          source: rule.source,
          explanation: imageQuality === "POOR" 
            ? "Important package declarations are not sufficiently visible for reliable verification due to poor image quality."
            : "Required evidence was not reliably visible in the supplied image.",
        });
      } else {
        // Field is present
        evaluations.push({
          ruleId: rule.ruleId,
          requirement: rule.requirement,
          status: 'PASS',
          evidence: canonicalEvidence.rawEvidence,
          confidence: canonicalEvidence.confidence,
          source: rule.source,
          explanation: "Evidence found satisfying the regulatory requirement.",
        });
      }
    }

    return evaluations;
  }

  static calculateOverallStatus(evaluations: RuleEvaluation[]): 'PASS' | 'REVIEW_REQUIRED' | 'POTENTIAL_ISSUE' {
    const applicable = evaluations.filter(e => e.status !== 'NOT_APPLICABLE');
    if (applicable.some(e => e.status === 'POTENTIAL_ISSUE')) {
      return 'POTENTIAL_ISSUE';
    }
    if (applicable.some(e => e.status === 'REVIEW_REQUIRED' || e.status === 'MISSING' || e.status === 'UNCERTAIN')) {
      return 'REVIEW_REQUIRED';
    }
    return 'PASS';
  }

  static validateConsistency(evaluations: RuleEvaluation[], extractedData: ExtractedData): boolean {
    for (const evalResult of evaluations) {
      if (evalResult.status === 'NOT_APPLICABLE') continue;
      
      const rule = LMPC_RULES.find(r => r.ruleId === evalResult.ruleId);
      if (!rule) return false;

      const canonical = this.normalizeEvidence(extractedData, rule);
      
      if (evalResult.status === 'PASS' && canonical.evidenceStatus !== 'FOUND') {
        return false;
      }
      if (evalResult.status === 'PASS' && evalResult.evidence !== canonical.rawEvidence) {
        return false;
      }
    }
    return true;
  }
}
