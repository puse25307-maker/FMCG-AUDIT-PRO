import React from "react";
import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import { Bell, LayoutDashboard, ClipboardList, FileText, Settings as SettingsIcon, PackageCheck } from "lucide-react";
import { cn } from "./lib/utils";

import Dashboard from "./pages/Dashboard";
import History from "./pages/History";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import NewInspection from "./pages/NewInspection";
import InspectionResult from "./pages/InspectionResult";

import ReportView from "./pages/ReportView";
import { NotificationsDropdown } from "./components/NotificationsDropdown";

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
        <PackageCheck className="w-5 h-5" />
      </div>
      <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
        FMCG-AuditPro
      </span>
    </div>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();

  const navItems = [
    { name: "Dashboard", path: "/", icon: LayoutDashboard, color: "blue", activeClass: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-500/10" },
    { name: "History", path: "/history", icon: ClipboardList, color: "violet", activeClass: "text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-500/10" },
    { name: "Reports", path: "/reports", icon: FileText, color: "teal", activeClass: "text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-500/10" },
    { name: "Settings", path: "/settings", icon: SettingsIcon, color: "amber", activeClass: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10" },
  ];

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-[#0A101D] text-slate-900 dark:text-slate-200 font-sans selection:bg-blue-500/30">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F1626]">
        <div className="p-6">
          <Logo />
        </div>
        <nav className="flex-1 px-4 space-y-2 mt-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                  isActive
                    ? item.activeClass
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50"
                )}
              >
                <item.icon className={cn("w-5 h-5", isActive ? "" : "opacity-70")} />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </aside>

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden relative">
        {/* Header */}
        <header className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0F1626] md:bg-transparent md:dark:bg-transparent md:border-none">
          <div className="flex items-center md:hidden">
            <Logo />
          </div>
          <div className="hidden md:block">
            {/* Breadcrumb or Page Title can go here */}
          </div>
          <div className="flex items-center gap-4 ml-auto">
            <NotificationsDropdown />
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8">
          <div className="max-w-5xl mx-auto">
            {children}
          </div>
        </main>

        {/* Floating Mobile Bottom Navigation */}
        <div className="md:hidden fixed bottom-6 left-4 right-4 z-50">
          <nav className="flex items-center justify-around p-2 bg-white/90 dark:bg-[#0F1626]/90 backdrop-blur-md border border-slate-200/50 dark:border-slate-800/50 rounded-2xl shadow-lg dark:shadow-2xl shadow-slate-200/50 dark:shadow-black/50">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex flex-col items-center gap-1 p-2.5 rounded-xl transition-all duration-300 min-w-[64px]",
                    isActive
                      ? item.activeClass
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                  )}
                >
                  <item.icon className={cn("w-5 h-5 transition-transform duration-300", isActive ? "scale-110" : "")} />
                  <span className={cn("text-[10px] font-medium transition-all duration-300", isActive ? "opacity-100" : "opacity-70")}>{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/history" element={<History />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/new-inspection" element={<NewInspection />} />
          <Route path="/inspection/:id" element={<InspectionResult />} />
          <Route path="/report/:id" element={<ReportView />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

