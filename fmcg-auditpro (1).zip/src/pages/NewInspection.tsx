import React, { useState, useRef } from "react";
import { Upload, Camera, X, ImageIcon, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function NewInspection() {
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    validateAndSetFile(selectedFile);
  };

  const validateAndSetFile = (selectedFile: File | undefined) => {
    setError(null);
    if (!selectedFile) return;

    // Validate size (5MB)
    if (selectedFile.size > 5 * 1024 * 1024) {
      setError("Image size must be less than 5MB");
      return;
    }

    // Validate type
    if (!selectedFile.type.startsWith('image/')) {
      setError("Please select a valid image file (JPG, PNG, WebP)");
      return;
    }

    setFile(selectedFile);
    
    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(selectedFile);
  };

  const handleRemove = () => {
    setFile(null);
    setPreview(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const handleAnalyze = async () => {
    if (!file) return;

    setIsAnalyzing(true);
    setError(null);

    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Analysis failed");
      }

      // Success, redirect to result
      navigate(`/inspection/${data.inspectionId}`);
    } catch (err: any) {
      setError(err.message || "Failed to connect to analysis server");
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-3xl mx-auto">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">New Inspection</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-2">Upload a clear image of the product packaging to begin preliminary compliance screening.</p>
      </div>

      <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden p-6 md:p-8 shadow-sm dark:shadow-none">
        
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-xl text-red-600 dark:text-red-400 text-sm text-center">
            {error}
          </div>
        )}

        {!preview ? (
          <div className="grid sm:grid-cols-2 gap-4">
            {/* Upload Box */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center justify-center gap-4 p-8 border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 bg-slate-50 dark:bg-slate-800/30 hover:bg-blue-50 dark:hover:bg-blue-500/5 rounded-2xl transition-all group h-64"
            >
              <div className="w-16 h-16 rounded-full bg-white dark:bg-slate-800 group-hover:bg-blue-100 dark:group-hover:bg-blue-500/20 flex items-center justify-center transition-colors shadow-sm dark:shadow-none">
                <Upload className="w-8 h-8 text-slate-400 group-hover:text-blue-500 dark:group-hover:text-blue-400" />
              </div>
              <div className="text-center">
                <p className="font-medium text-slate-700 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400">Upload Image</p>
                <p className="text-xs text-slate-500 mt-1">JPG, PNG, WebP up to 5MB</p>
              </div>
            </button>
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef} 
              accept="image/*" 
              onChange={handleFileChange} 
            />

            {/* Camera Box */}
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="flex flex-col items-center justify-center gap-4 p-8 border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 bg-slate-50 dark:bg-slate-800/30 hover:bg-blue-50 dark:hover:bg-blue-500/5 rounded-2xl transition-all group h-64"
            >
              <div className="w-16 h-16 rounded-full bg-white dark:bg-slate-800 group-hover:bg-blue-100 dark:group-hover:bg-blue-500/20 flex items-center justify-center transition-colors shadow-sm dark:shadow-none">
                <Camera className="w-8 h-8 text-slate-400 group-hover:text-blue-500 dark:group-hover:text-blue-400" />
              </div>
              <div className="text-center">
                <p className="font-medium text-slate-700 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400">Use Device Camera</p>
                <p className="text-xs text-slate-500 mt-1">Take a picture directly</p>
              </div>
            </button>
            <input 
              type="file" 
              className="hidden" 
              ref={cameraInputRef} 
              accept="image/*" 
              capture="environment"
              onChange={handleFileChange} 
            />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-900 group">
              <img src={preview} alt="Product Preview" className="w-full h-[400px] object-contain" />
              
              {!isAnalyzing && (
                <button 
                  onClick={handleRemove}
                  className="absolute top-4 right-4 bg-white/80 dark:bg-slate-900/80 hover:bg-red-500 hover:text-white text-slate-700 dark:text-white p-2 rounded-full backdrop-blur-sm transition-colors shadow-sm"
                  aria-label="Remove image"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleRemove}
                disabled={isAnalyzing}
                className="flex-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50 text-slate-700 dark:text-white py-3.5 rounded-xl font-medium transition-colors border border-slate-200 dark:border-transparent"
              >
                Cancel
              </button>
              <button
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                className="flex-[2] bg-blue-600 hover:bg-blue-700 disabled:opacity-70 text-white py-3.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analyzing Label...
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-5 h-5" />
                    Analyze Label
                  </>
                )}
              </button>
            </div>
            
            {isAnalyzing && (
              <div className="text-center text-sm text-slate-500 dark:text-slate-400 animate-pulse">
                Identifying product and reading package declarations...
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
