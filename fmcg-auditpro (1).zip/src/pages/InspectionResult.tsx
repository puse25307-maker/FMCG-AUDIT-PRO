import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, CheckCircle2, AlertTriangle, AlertCircle, PackageSearch, ShieldCheck } from "lucide-react";

export default function InspectionResult() {
  const { id } = useParams();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/inspections/${id}`)
      .then(res => res.json())
      .then(data => {
        setData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[50vh]">
        <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
      </div>
    );
  }

  if (!data || data.error) {
    return (
      <div className="text-center py-20">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Inspection not found</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-6">The requested record could not be loaded.</p>
        <Link to="/history" className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium">← Back to History</Link>
      </div>
    );
  }

  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'PRELIMINARILY_COMPLIANT':
        return { color: 'text-emerald-700 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-400/10', border: 'border-emerald-200 dark:border-emerald-400/20', icon: CheckCircle2, label: 'Preliminarily Compliant' };
      case 'REVIEW_REQUIRED':
        return { color: 'text-amber-700 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-400/10', border: 'border-amber-200 dark:border-amber-400/20', icon: AlertTriangle, label: 'Review Required' };
      case 'POTENTIAL_ISSUE':
        return { color: 'text-red-700 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-400/10', border: 'border-red-200 dark:border-red-400/20', icon: AlertCircle, label: 'Potential Issue' };
      default:
        return { color: 'text-slate-700 dark:text-slate-400', bg: 'bg-slate-100 dark:bg-slate-800', border: 'border-slate-200 dark:border-slate-700', icon: AlertCircle, label: 'Unknown' };
    }
  };

  const statusConfig = getStatusDisplay(data.status);
  const StatusIcon = statusConfig.icon;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center gap-4 mb-2">
        <Link to="/history" className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Inspection Result</h1>
      </div>

      {/* Primary Status Card */}
      <div className={`rounded-2xl border ${statusConfig.border} ${statusConfig.bg} p-6 md:p-8 flex items-center justify-between`}>
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${statusConfig.color} bg-white/50 dark:bg-white/5`}>
            <StatusIcon className="w-6 h-6" />
          </div>
          <div>
            <h2 className={`text-xl md:text-2xl font-bold ${statusConfig.color}`}>{statusConfig.label}</h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">ID: {data.id} • {new Date(data.date).toLocaleString()}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Product Identity */}
        <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-none">
          <h3 className="text-sm font-semibold tracking-wider text-slate-500 uppercase flex items-center gap-2 mb-4">
            <PackageSearch className="w-4 h-4" />
            Product Detected
          </h3>
          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <dt className="text-xs text-slate-500 mb-1">Brand</dt>
              <dd className="text-sm font-medium text-slate-900 dark:text-slate-200">{data.productIdentity?.brand || 'N/A'}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500 mb-1">Product Name</dt>
              <dd className="text-sm font-medium text-slate-900 dark:text-slate-200">{data.productIdentity?.productName || 'N/A'}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500 mb-1">Category</dt>
              <dd className="text-sm font-medium text-slate-900 dark:text-slate-200">{data.productIdentity?.category || 'N/A'}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500 mb-1">Subcategory</dt>
              <dd className="text-sm font-medium text-slate-900 dark:text-slate-200">{data.productIdentity?.subcategory || 'N/A'}</dd>
            </div>
          </dl>
          {data.productIdentity?.confidence && (
            <div className="mt-4 flex items-center gap-2 text-xs text-slate-500">
              <span className={`w-2 h-2 rounded-full ${data.productIdentity.confidence > 0.8 ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
              {(data.productIdentity.confidence * 100).toFixed(0)}% AI Confidence
            </div>
          )}
        </div>

        {/* Regulatory Analysis */}
        <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-none">
          <h3 className="text-sm font-semibold tracking-wider text-slate-500 uppercase flex items-center gap-2 mb-4">
            <ShieldCheck className="w-4 h-4" />
            Regulatory Analysis
          </h3>
          <div className="space-y-4">
            <div className="bg-slate-50 dark:bg-slate-800/30 rounded-xl p-4 border border-slate-200 dark:border-slate-700/50">
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">Message</div>
              <p className="text-sm text-slate-700 dark:text-slate-300">
                {data.message || "Analysis complete."}
              </p>
            </div>
            
            {data.regulatoryAnalysis?.applicableRegulations && (
               <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                 <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">Applicable Regulations</div>
                 <ul className="list-disc pl-4 space-y-1">
                   {data.regulatoryAnalysis.applicableRegulations.map((reg: string, idx: number) => (
                     <li key={idx} className="text-sm text-slate-700 dark:text-slate-300">{reg}</li>
                   ))}
                 </ul>
               </div>
            )}

            {data.imageQuality && (
              <div className="flex justify-between items-center text-sm border-t border-slate-100 dark:border-slate-800 pt-4">
                <span className="text-slate-500">Image Quality</span>
                <span className={`font-medium ${data.imageQuality.status === 'GOOD' ? 'text-emerald-600 dark:text-emerald-400' : data.imageQuality.status === 'FAIR' ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>
                  {data.imageQuality.status}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Declaration Verification */}
      {data.regulatoryAnalysis?.evaluations && (
        <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-none">
           <h3 className="text-sm font-semibold tracking-wider text-slate-500 uppercase mb-6">
            Declaration Verification
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            {data.regulatoryAnalysis.evaluations.map((evalRecord: any, idx: number) => {
              const getEvalStatusDisplay = (status: string) => {
                switch (status) {
                  case 'PASS': return { bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800/50', icon: '✓', text: 'Evidence Found' };
                  case 'REVIEW_REQUIRED': return { bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800/50', icon: '?', text: 'Review Required' };
                  case 'POTENTIAL_ISSUE': return { bg: 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800/50', icon: '✕', text: 'Potential Issue' };
                  case 'NOT_APPLICABLE': return { bg: 'bg-slate-50 text-slate-500 border-slate-200 dark:bg-slate-800/50 dark:text-slate-400 dark:border-slate-700', icon: '—', text: 'Not Applicable' };
                  default: return { bg: 'bg-slate-50 text-slate-500 border-slate-200 dark:bg-slate-800/50 dark:text-slate-400 dark:border-slate-700', icon: '?', text: 'Unknown' };
                }
              };
              const evalStatus = getEvalStatusDisplay(evalRecord.status);

              return (
                <div key={idx} className="border-b border-slate-100 dark:border-slate-800/50 pb-4 last:border-0 md:[&:nth-last-child(-n+2)]:border-0">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-300 pr-2">{evalRecord.requirement}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full border whitespace-nowrap ${evalStatus.bg}`}>
                      {evalStatus.icon} {evalStatus.text}
                    </span>
                  </div>
                  
                  {evalRecord.status !== 'NOT_APPLICABLE' && (
                    <div className="space-y-2 mt-2">
                      <div className="text-xs text-slate-500 dark:text-slate-400">{evalRecord.explanation}</div>
                      
                      {evalRecord.evidence && (
                        <div className="bg-slate-50 dark:bg-slate-900/50 rounded-lg p-3 border border-slate-100 dark:border-slate-800">
                          <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-1">Extracted Evidence</div>
                          <div className="text-sm text-slate-700 dark:text-slate-300 font-mono text-wrap break-words">{evalRecord.evidence}</div>
                        </div>
                      )}
                      
                      <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-2">
                        Source: {evalRecord.source}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
      
      {/* Disclaimer */}
      <div className="mt-8 text-center px-4">
        <p className="text-xs text-slate-500 dark:text-slate-600">
          FMCG-AuditPro provides preliminary compliance screening based on the supplied package image and currently encoded regulatory requirements. It is not a legally binding determination.
        </p>
      </div>
    </div>
  );
}
