import React, { useEffect, useState } from "react";
import { InspectionRecord } from "../types";
import { ArrowRight, Search, FileText } from "lucide-react";
import { Link } from "react-router-dom";

export default function History() {
  const [inspections, setInspections] = useState<InspectionRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/inspections')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setInspections(data);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Inspection History</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Review past compliance screening records</p>
        </div>
        
        {inspections.length > 0 && (
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500" />
            <input 
              type="text" 
              placeholder="Search records..." 
              className="w-full sm:w-64 bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white pl-10 pr-4 py-2 rounded-xl text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all shadow-sm dark:shadow-none"
            />
          </div>
        )}
      </div>

      <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden min-h-[400px] flex flex-col shadow-sm dark:shadow-none">
        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
          </div>
        ) : inspections.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-4 border border-slate-200 dark:border-slate-700/50">
              <FileText className="w-8 h-8 text-slate-400 dark:text-slate-500" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No inspection data yet</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-sm mb-6">
              Your inspection history is empty. Start scanning products to see them listed here.
            </p>
            <Link
              to="/new-inspection"
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-sm font-medium transition-colors flex items-center gap-2"
            >
              <ArrowRight className="w-4 h-4" />
              New Inspection
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-500 dark:text-slate-400">
              <thead className="bg-slate-50 dark:bg-slate-800/30 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Product / Brand</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Category</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Date</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Status</th>
                  <th className="px-6 py-4 font-medium text-right border-b border-slate-200 dark:border-slate-800">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/50">
                {inspections.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-900 dark:text-slate-200">{item.productIdentity?.productName || "Unknown Product"}</div>
                      <div className="text-xs text-slate-500">{item.productIdentity?.brand || "Unknown Brand"}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{item.productIdentity?.category || "-"}</td>
                    <td className="px-6 py-4">{new Date(item.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4">
                      {item.status === 'PASS' && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 border border-emerald-200 dark:border-emerald-400/20">Pass</span>}
                      {item.status === 'REVIEW_REQUIRED' && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/20">Review Required</span>}
                      {item.status === 'POTENTIAL_ISSUE' && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-400/10 border border-red-200 dark:border-red-400/20">Potential Issue</span>}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Link to={`/inspection/${item.id}`} className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium text-sm">
                        View Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
