import React, { useEffect, useState } from "react";
import { FileBarChart2, FileDown, Eye, Search, Filter } from "lucide-react";
import { InspectionRecord } from "../types";
import { Link, useNavigate } from "react-router-dom";

export default function Reports() {
  const [inspections, setInspections] = useState<InspectionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Filters and search
  const [filterStatus, setFilterStatus] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/inspections')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setInspections(data);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const handleGenerateReport = (id: string) => {
    navigate(`/report/${id}`);
  };

  // Calculate metrics
  const totalReports = inspections.length;
  const passCount = inspections.filter(i => i.status === 'PASS').length;
  const reviewRequiredCount = inspections.filter(i => i.status === 'REVIEW_REQUIRED').length;
  const potentialIssueCount = inspections.filter(i => i.status === 'POTENTIAL_ISSUE').length;

  // Filter and search logic
  const filteredInspections = inspections.filter(item => {
    const matchesStatus = filterStatus === "ALL" || item.status === filterStatus;
    const searchLower = searchQuery.toLowerCase();
    const productName = item.productIdentity?.productName?.toLowerCase() || "";
    const brandName = item.productIdentity?.brand?.toLowerCase() || "";
    const idString = item.id.toLowerCase();
    const matchesSearch = productName.includes(searchLower) || brandName.includes(searchLower) || idString.includes(searchLower);
    
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Reports</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Export and view professional compliance summaries</p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm dark:shadow-none">
          <div className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">Total Reports</div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white">{totalReports}</div>
        </div>
        <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800/30 rounded-2xl p-4 shadow-sm dark:shadow-none">
          <div className="text-sm font-medium text-emerald-600 dark:text-emerald-400 mb-1">Pass</div>
          <div className="text-2xl font-bold text-emerald-700 dark:text-emerald-300">{passCount}</div>
        </div>
        <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800/30 rounded-2xl p-4 shadow-sm dark:shadow-none">
          <div className="text-sm font-medium text-amber-600 dark:text-amber-400 mb-1">Review Required</div>
          <div className="text-2xl font-bold text-amber-700 dark:text-amber-300">{reviewRequiredCount}</div>
        </div>
        <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-800/30 rounded-2xl p-4 shadow-sm dark:shadow-none">
          <div className="text-sm font-medium text-red-600 dark:text-red-400 mb-1">Potential Issues</div>
          <div className="text-2xl font-bold text-red-700 dark:text-red-300">{potentialIssueCount}</div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-96">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-slate-400" />
          </div>
          <input
            type="text"
            placeholder="Search by Product, Brand, or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-slate-200 dark:border-slate-700 rounded-xl leading-5 bg-white dark:bg-[#0F1626] text-slate-900 dark:text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors"
          />
        </div>
        <div className="flex gap-2 w-full sm:w-auto overflow-x-auto pb-2 sm:pb-0 hide-scrollbar">
          {["ALL", "PASS", "REVIEW_REQUIRED", "POTENTIAL_ISSUE"].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors border ${
                filterStatus === status
                  ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800/50'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 dark:bg-[#121A2F] dark:text-slate-400 dark:border-slate-800 dark:hover:bg-slate-800'
              }`}
            >
              {status === 'ALL' ? 'All Reports' : status === 'REVIEW_REQUIRED' ? 'Review Required' : status === 'POTENTIAL_ISSUE' ? 'Potential Issue' : 'Pass'}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden min-h-[400px] flex flex-col shadow-sm dark:shadow-none">
        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
          </div>
        ) : filteredInspections.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-4 border border-slate-200 dark:border-slate-700/50">
              <FileBarChart2 className="w-8 h-8 text-slate-400 dark:text-slate-500" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No reports found</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-sm mb-6">
              {inspections.length > 0 ? "No reports match your current filters." : "Complete an inspection to generate a compliance report."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-500 dark:text-slate-400">
              <thead className="bg-slate-50 dark:bg-slate-800/30 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Product / Brand</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Category</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Date</th>
                  <th className="px-6 py-4 font-medium border-b border-slate-200 dark:border-slate-800">Compliance Status</th>
                  <th className="px-6 py-4 font-medium text-right border-b border-slate-200 dark:border-slate-800">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/50">
                {filteredInspections.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-900 dark:text-slate-200">{item.productIdentity?.productName || "Unknown Product"}</div>
                      <div className="text-xs text-slate-500">{item.productIdentity?.brand || "Unknown Brand"}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-1">{item.id}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{item.productIdentity?.category || "-"}</td>
                    <td className="px-6 py-4">{new Date(item.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4">
                      {item.status === 'PASS' && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 border border-emerald-200 dark:border-emerald-400/20">Pass</span>}
                      {item.status === 'REVIEW_REQUIRED' && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 border border-amber-200 dark:border-amber-400/20">Review Required</span>}
                      {item.status === 'POTENTIAL_ISSUE' && <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-400/10 border border-red-200 dark:border-red-400/20">Potential Issue</span>}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-3">
                        <Link to={`/inspection/${item.id}`} className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors flex items-center gap-1" title="View Analysis">
                          <Eye className="w-4 h-4" />
                          <span className="sr-only sm:not-sr-only sm:text-xs">Analysis</span>
                        </Link>
                        <button 
                          onClick={() => handleGenerateReport(item.id)}
                          className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors flex items-center gap-1"
                          title="Generate Report"
                        >
                          <FileDown className="w-4 h-4" />
                          <span className="sr-only sm:not-sr-only sm:text-xs font-medium">Report</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
