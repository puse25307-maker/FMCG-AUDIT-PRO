import React from "react";
import { ShieldAlert, Info, Moon, Sun, Monitor } from "lucide-react";
import { useTheme } from "../lib/theme";

export default function Settings() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Settings</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Manage application preferences</p>
      </div>

      <div className="grid gap-6">
        {/* Theme Settings */}
        <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm dark:shadow-none">
          <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-800/50 flex items-center gap-3">
            <Monitor className="w-5 h-5 text-slate-400" />
            <h2 className="text-lg font-medium text-slate-900 dark:text-white">Appearance</h2>
          </div>
          <div className="p-6">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setTheme("dark")}
                className={`flex-1 p-4 rounded-xl flex flex-col items-center gap-2 transition-colors border ${
                  theme === "dark" 
                    ? "bg-blue-50 dark:bg-blue-600/10 border-blue-500 text-blue-600 dark:text-blue-400" 
                    : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400"
                }`}
              >
                <Moon className="w-6 h-6" />
                <span className="text-sm font-medium">Dark Mode</span>
              </button>
              <button 
                onClick={() => setTheme("light")}
                className={`flex-1 p-4 rounded-xl flex flex-col items-center gap-2 transition-colors border ${
                  theme === "light" 
                    ? "bg-blue-50 dark:bg-blue-600/10 border-blue-500 text-blue-600 dark:text-blue-400" 
                    : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400"
                }`}
              >
                <Sun className="w-6 h-6" />
                <span className="text-sm font-medium">Light Mode</span>
              </button>
              <button 
                onClick={() => setTheme("system")}
                className={`flex-1 p-4 rounded-xl flex flex-col items-center gap-2 transition-colors border ${
                  theme === "system" 
                    ? "bg-blue-50 dark:bg-blue-600/10 border-blue-500 text-blue-600 dark:text-blue-400" 
                    : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400"
                }`}
              >
                <Monitor className="w-6 h-6" />
                <span className="text-sm font-medium">System</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-4">
              Choose your preferred visual style.
            </p>
          </div>
        </div>

        {/* About & Disclaimer */}
        <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm dark:shadow-none">
          <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-800/50 flex items-center gap-3">
            <Info className="w-5 h-5 text-slate-400" />
            <h2 className="text-lg font-medium text-slate-900 dark:text-white">About FMCG-AuditPro</h2>
          </div>
          <div className="p-6 space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              FMCG-AuditPro is an AI-assisted tool designed to automate and streamline the extraction, verification, and compliance-checking of FMCG packaging labels.
            </p>
            <div className="bg-amber-50 dark:bg-amber-500/5 border border-amber-200 dark:border-amber-500/20 rounded-xl p-4 flex gap-3 items-start">
              <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-amber-800 dark:text-amber-500 mb-1">Regulatory Disclaimer</h4>
                <p className="text-xs text-amber-700 dark:text-amber-400/80 leading-relaxed">
                  FMCG-AuditPro provides preliminary compliance screening based on the supplied package image and currently encoded regulatory requirements. It is not a legally binding determination. Do not claim 100% legal compliance based solely on this tool's output. Always consult with legal and regulatory professionals for final compliance certification.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
