import { Link } from "react-router-dom";
import { ArrowRight, History, CheckCircle2, AlertTriangle, AlertCircle, LayoutDashboard } from "lucide-react";
import React, { useEffect, useState } from "react";
import { InspectionRecord } from "../types";

export default function Dashboard() {
  const [metrics, setMetrics] = useState({
    totalScans: 0,
    compliant: 0,
    reviewRequired: 0,
    potentialIssues: 0,
  });

  const [recentActivity, setRecentActivity] = useState<InspectionRecord[]>([]);
  const [inspections, setInspections] = useState<InspectionRecord[]>([]);

  useEffect(() => {
    // Fetch real metrics from API
    fetch('/api/inspections')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setInspections(data);
          setRecentActivity(data.slice(0, 3));
          
          setMetrics({
            totalScans: data.length,
            compliant: data.filter(d => d.status === 'PASS').length,
            reviewRequired: data.filter(d => d.status === 'REVIEW_REQUIRED').length,
            potentialIssues: data.filter(d => d.status === 'POTENTIAL_ISSUE').length,
          });
        }
      })
      .catch(err => console.error("Failed to fetch inspections", err));
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-50 to-white dark:from-blue-900/40 dark:to-slate-900 border border-blue-100 dark:border-slate-800 p-8 md:p-10 shadow-sm dark:shadow-none">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-blue-100 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 text-xs font-semibold mb-4 border border-blue-200 dark:border-blue-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 animate-pulse"></span>
            SYSTEM READY
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4 leading-tight">
            AI-Assisted Evidence-Based <br className="hidden md:block" />
            Packaging Compliance Inspection
          </h1>
          <p className="text-slate-600 dark:text-slate-400 max-w-xl mb-8">
            Scan and digitize packaged commodity labels for preliminary compliance screening. Powered by automated rule extraction and analysis.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/new-inspection"
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors shadow-lg shadow-blue-600/20 dark:shadow-blue-900/20"
            >
              <ArrowRight className="w-5 h-5" />
              New Inspection
            </Link>
            <Link
              to="/history"
              className="inline-flex items-center gap-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-white px-6 py-3 rounded-xl font-medium transition-colors border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-none"
            >
              View Records
            </Link>
          </div>
        </div>
        
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-[400px] h-[400px] rounded-full bg-blue-500/5 blur-[100px] pointer-events-none"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Metrics Overview */}
        <div className="md:col-span-5 lg:col-span-4 space-y-4">
          <h2 className="text-sm font-semibold tracking-wider text-slate-500 uppercase flex items-center gap-2 mb-2">
            <LayoutDashboard className="w-4 h-4" />
            Metrics Overview
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 gap-4">
            <MetricCard 
              title="Total Scans" 
              value={metrics.totalScans} 
              subtitle="All recorded inspections"
              icon={<History className="w-4 h-4 text-slate-400" />}
            />
            <MetricCard 
              title="Compliant" 
              value={metrics.compliant} 
              subtitle={`${metrics.totalScans ? Math.round((metrics.compliant / metrics.totalScans) * 100) : 0}% compliance rate`}
              icon={<CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />}
              accentColor="emerald"
            />
            <MetricCard 
              title="Review Required" 
              value={metrics.reviewRequired} 
              subtitle={`${metrics.totalScans ? Math.round((metrics.reviewRequired / metrics.totalScans) * 100) : 0}% of total`}
              icon={<AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400" />}
              accentColor="amber"
            />
            <MetricCard 
              title="Action Needed" 
              value={metrics.potentialIssues} 
              subtitle={`${metrics.totalScans ? Math.round((metrics.potentialIssues / metrics.totalScans) * 100) : 0}% of total`}
              icon={<AlertCircle className="w-4 h-4 text-red-500 dark:text-red-400" />}
              accentColor="red"
            />
          </div>
        </div>

        {/* Recent Activity & Insights */}
        <div className="md:col-span-7 lg:col-span-8 space-y-8">
          <section>
            <h2 className="text-sm font-semibold tracking-wider text-slate-500 uppercase flex items-center gap-2 mb-4">
              <History className="w-4 h-4" />
              Recent Activity
            </h2>
            
            <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden min-h-[300px] flex flex-col shadow-sm dark:shadow-none">
              {recentActivity.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                  <div className="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-4 border border-slate-200 dark:border-slate-700/50">
                    <ArrowRight className="w-8 h-8 text-slate-400 dark:text-slate-500" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">No inspection data yet</h3>
                  <p className="text-slate-500 dark:text-slate-400 max-w-sm mb-6">
                    Start your first product inspection to begin building your inspection history.
                  </p>
                  <Link
                    to="/new-inspection"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-sm font-medium transition-colors flex items-center gap-2"
                  >
                    <ArrowRight className="w-4 h-4" />
                    Start New Inspection
                  </Link>
                </div>
              ) : (
                <div className="divide-y divide-slate-200 dark:divide-slate-800/50">
                  {recentActivity.map(item => (
                    <div key={item.id} className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <div>
                        <p className="font-medium text-slate-900 dark:text-slate-200">{item.productIdentity?.productName || "Unknown Product"}</p>
                        <p className="text-sm text-slate-500">{new Date(item.date).toLocaleString()}</p>
                      </div>
                      <div className="text-sm">
                        {item.status === 'PASS' && <span className="text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-400/10 px-2 py-1 rounded">Pass</span>}
                        {item.status === 'REVIEW_REQUIRED' && <span className="text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 px-2 py-1 rounded">Review Needed</span>}
                        {item.status === 'POTENTIAL_ISSUE' && <span className="text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-400/10 px-2 py-1 rounded">Issue Found</span>}
                      </div>
                    </div>
                  ))}
                  <div className="p-4 text-center border-t border-slate-200 dark:border-slate-800/50">
                     <Link to="/history" className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 text-sm font-medium">View all history →</Link>
                  </div>
                </div>
              )}
            </div>
          </section>

          <section>
            <h2 className="text-sm font-semibold tracking-wider text-slate-500 uppercase flex items-center gap-2 mb-4">
              <History className="w-4 h-4" />
              Historical Insights
            </h2>
            
            {(() => {
              const historyItem = Array.isArray(inspections) && inspections.find(i => i.historicalComparison);
              if (!historyItem || !historyItem.historicalComparison) {
                return (
                  <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-sm dark:shadow-none">
                    <div className="w-12 h-12 rounded-full bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center mb-3">
                      <AlertCircle className="w-6 h-6 text-slate-400 dark:text-slate-500" />
                    </div>
                    <h3 className="text-sm font-medium text-slate-900 dark:text-white mb-1">No historical comparisons yet</h3>
                    <p className="text-xs text-slate-500">
                      Complete inspections over time to detect potential changes.
                    </p>
                  </div>
                );
              }
              const hc = historyItem.historicalComparison;
              return (
                <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-none">
                  <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800/30 rounded-xl p-4">
                    <div className="text-sm font-medium text-amber-800 dark:text-amber-400 mb-1">{historyItem.productIdentity?.brand} {historyItem.productIdentity?.productName}</div>
                    <div className="text-xs text-amber-700/70 dark:text-amber-500/70 mb-3">Quantity reduction detected</div>
                    
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-xs text-slate-500">Previous ({new Date(hc.previousDate).toLocaleDateString()})</div>
                        <div className="font-medium">{hc.previousQuantity}</div>
                        <div className="text-xs text-slate-500">MRP: {hc.previousMrp || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-500">Current ({new Date(historyItem.date).toLocaleDateString()})</div>
                        <div className="font-medium">{hc.currentQuantity}</div>
                        <div className="text-xs text-slate-500">MRP: {hc.currentMrp || 'N/A'}</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </section>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ 
  title, 
  value, 
  subtitle, 
  icon,
  accentColor = "blue"
}: { 
  title: string, 
  value: number, 
  subtitle: string, 
  icon: React.ReactNode,
  accentColor?: "blue" | "emerald" | "amber" | "red"
}) {
  const colorMap = {
    blue: "border-blue-500/20 bg-blue-500/5",
    emerald: "border-emerald-500/20 bg-emerald-500/5",
    amber: "border-amber-500/20 bg-amber-500/5",
    red: "border-red-500/20 bg-red-500/5",
  };

  return (
    <div className="bg-white dark:bg-[#121A2F] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col relative overflow-hidden shadow-sm dark:shadow-none">
      <div className="flex justify-between items-start mb-4 relative z-10">
        <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{title}</h3>
        {icon}
      </div>
      <div className="relative z-10">
        <span className="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">{value}</span>
        <p className="text-xs text-slate-500 mt-2">{subtitle}</p>
      </div>
      
      {/* Subtle background glow based on accent color if value > 0 */}
      {value > 0 && accentColor !== "blue" && (
        <div className={`absolute -right-10 -bottom-10 w-32 h-32 rounded-full blur-[50px] opacity-10 dark:opacity-20 bg-${accentColor}-500 pointer-events-none`}></div>
      )}
    </div>
  );
}
