import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Printer, ShieldCheck, AlertTriangle, Info, Download } from "lucide-react";
import { InspectionRecord } from "../types";

export default function ReportView() {
  const { id } = useParams<{ id: string }>();
  const [report, setReport] = useState<InspectionRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/inspections')
      .then(res => res.json())
      .then((data: InspectionRecord[]) => {
        const found = data.find(i => i.id === id);
        if (found) setReport(found);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Report Not Found</h2>
        <p className="text-slate-500 mt-2">The requested inspection record could not be found.</p>
        <Link to="/reports" className="text-blue-600 hover:underline mt-4 inline-block">Back to Reports</Link>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = async () => {
    // html2canvas (used by html2pdf) crashes on Tailwind v4's oklch colors. 
    // We temporarily proxy getComputedStyle to sanitize these colors before they hit the parser.
    const originalGetComputedStyle = window.getComputedStyle;
    
    try {
      window.getComputedStyle = function(el, pseudoElt) {
        const style = originalGetComputedStyle(el, pseudoElt);
        return new Proxy(style, {
          get(target, prop, receiver) {
            if (prop === 'getPropertyValue') {
              return function(property: string) {
                const val = target.getPropertyValue(property);
                if (val && typeof val === 'string' && val.includes('oklch')) {
                   // Strip oklch to prevent parser crash, fallback to a safe neutral color
                   return val.replace(/oklch\([^)]+\)/g, 'rgb(148, 163, 184)'); 
                }
                return val;
              };
            }
            const val = Reflect.get(target, prop, receiver);
            if (typeof val === 'string' && val.includes('oklch')) {
              return val.replace(/oklch\([^)]+\)/g, 'rgb(148, 163, 184)');
            }
            if (typeof val === 'function') {
              return val.bind(target);
            }
            return val;
          }
        });
      };

      const html2pdf = (await import('html2pdf.js')).default;
      const element = document.getElementById('report-content');
      
      if (!element) throw new Error("Report content not found");

      const opt = {
        margin:       [10, 10, 10, 10] as [number, number, number, number],
        filename:     `FMCG-AuditPro_Inspection_${report.id}.pdf`,
        image:        { type: 'jpeg' as const, quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true, logging: false },
        jsPDF:        { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const }
      };

      await html2pdf().set(opt).from(element).save();
    } catch (err) {
      console.error("PDF generation failed:", err);
      alert("PDF generation failed. Please use Print → Save as PDF.");
    } finally {
      window.getComputedStyle = originalGetComputedStyle;
    }
  };

  const totalEvaluations = report.regulatoryAnalysis?.evaluations.length || 0;
  const passedCount = report.regulatoryAnalysis?.evaluations.filter(e => e.status === 'PASS').length || 0;
  const reviewCount = report.regulatoryAnalysis?.evaluations.filter(e => e.status === 'REVIEW_REQUIRED' || e.status === 'UNCERTAIN' || e.status === 'MISSING').length || 0;
  const issueCount = report.regulatoryAnalysis?.evaluations.filter(e => e.status === 'POTENTIAL_ISSUE').length || 0;
  const naCount = report.regulatoryAnalysis?.evaluations.filter(e => e.status === 'NOT_APPLICABLE').length || 0;
  const applicableCount = totalEvaluations - naCount;

  // Determine Overall Status string
  let statusText = "PASS";
  let statusColor = "text-emerald-700 bg-emerald-50 border-emerald-200";
  let statusDesc = "All currently applicable encoded requirements were satisfied based on the available package evidence.";
  
  if (report.status === 'POTENTIAL_ISSUE') {
    statusText = "POTENTIAL ISSUE";
    statusColor = "text-red-700 bg-red-50 border-red-200";
    statusDesc = "A potential compliance issue was identified against an encoded regulatory requirement. Human verification is recommended.";
  } else if (report.status === 'REVIEW_REQUIRED') {
    statusText = "REVIEW REQUIRED";
    statusColor = "text-amber-700 bg-amber-50 border-amber-200";
    statusDesc = "Some applicable declarations could not be reliably verified from the supplied package image. Human verification is recommended.";
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Non-printable controls */}
      <div className="flex justify-between items-center mb-6 print:hidden">
        <Link to="/reports" className="flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to Reports
        </Link>
        <div className="flex items-center gap-3">
          <button 
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-sm font-medium transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
          <button 
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-medium transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Download PDF
          </button>
        </div>
      </div>

      {/* Printable Report Container */}
      <div id="report-content" className="bg-white text-slate-900 print:shadow-none print:border-none border border-slate-200 rounded-2xl p-8 md:p-12 shadow-sm space-y-12">
        
        {/* Header */}
        <div className="border-b-2 border-slate-900 pb-6 text-center space-y-2">
          <h1 className="text-2xl font-bold tracking-tight uppercase">FMCG-AuditPro</h1>
          <p className="text-sm font-medium text-slate-500 uppercase tracking-widest">AI-Assisted Evidence-Based Packaging Compliance Inspection</p>
          <h2 className="text-3xl font-black mt-4 tracking-tight">PACKAGING COMPLIANCE SCREENING REPORT</h2>
          
          <div className="grid grid-cols-2 gap-4 text-left text-sm mt-8 p-4 bg-slate-50 rounded-xl border border-slate-100">
            <div><span className="text-slate-500">Inspection ID:</span> <span className="font-mono font-medium">{report.id}</span></div>
            <div><span className="text-slate-500">Date:</span> <span className="font-medium">{new Date(report.date).toLocaleString()}</span></div>
            <div><span className="text-slate-500">Brand:</span> <span className="font-medium">{report.productIdentity?.brand || 'Unknown'}</span></div>
            <div><span className="text-slate-500">Product:</span> <span className="font-medium">{report.productIdentity?.productName || 'Unknown'}</span></div>
          </div>
        </div>

        {/* Executive Summary */}
        <section>
          <h3 className="text-xl font-bold border-b border-slate-200 pb-2 mb-4">Executive Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className={`p-6 rounded-xl border ${statusColor} flex flex-col justify-center`}>
              <div className="text-sm font-bold uppercase tracking-wider mb-1 opacity-80">Overall Status</div>
              <div className="text-3xl font-black tracking-tight">{statusText}</div>
              <div className="text-sm mt-2 opacity-90">{statusDesc}</div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Applicable Requirements</div>
                <div className="text-2xl font-bold mt-1">{applicableCount}</div>
              </div>
              <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 text-emerald-800">
                <div className="text-xs font-semibold uppercase tracking-wider">Evidence Found</div>
                <div className="text-2xl font-bold mt-1">{passedCount}</div>
              </div>
              <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 text-amber-800">
                <div className="text-xs font-semibold uppercase tracking-wider">Review Required</div>
                <div className="text-2xl font-bold mt-1">{reviewCount}</div>
              </div>
              <div className="bg-red-50 p-4 rounded-xl border border-red-100 text-red-800">
                <div className="text-xs font-semibold uppercase tracking-wider">Potential Issues</div>
                <div className="text-2xl font-bold mt-1">{issueCount}</div>
              </div>
            </div>
          </div>
        </section>

        {/* Product Identification */}
        <section>
          <h3 className="text-xl font-bold border-b border-slate-200 pb-2 mb-4">Product Identification</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <div className="flex justify-between border-b border-slate-100 pb-2">
                <span className="text-slate-500">Brand</span>
                <span className="font-medium">{report.productIdentity?.brand || '-'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-2">
                <span className="text-slate-500">Product Name</span>
                <span className="font-medium">{report.productIdentity?.productName || '-'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-2">
                <span className="text-slate-500">Category</span>
                <span className="font-medium">{report.productIdentity?.category || '-'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-2">
                <span className="text-slate-500">Subcategory</span>
                <span className="font-medium">{report.productIdentity?.subcategory || '-'}</span>
              </div>
              <div className="flex justify-between border-b border-slate-100 pb-2">
                <span className="text-slate-500">Identification Method</span>
                <span className="font-medium text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">AI-assisted multimodal package analysis</span>
              </div>
            </div>
            
            <div className="bg-slate-50 rounded-xl border border-slate-200 flex flex-col items-center justify-center p-2 text-center text-slate-400 min-h-[200px]">
               {report.imageUrl ? (
                 <div className="w-full h-full flex flex-col items-center justify-center">
                   <img src={report.imageUrl} alt="Source Package" className="max-h-64 object-contain rounded-lg shadow-sm border border-slate-200" />
                   <div className="text-xs text-slate-500 mt-2 font-medium">Source Image Used for Screening</div>
                   <div className="text-[10px] text-slate-400">Image Quality: {report.imageQuality?.status}</div>
                 </div>
               ) : (
                 <div className="p-6">
                   <div className="text-sm font-medium text-slate-500">Source package image unavailable for this inspection record.</div>
                   <div className="text-xs mt-1 text-slate-400">Image Quality: {report.imageQuality?.status}</div>
                 </div>
               )}
            </div>
          </div>
        </section>

        {/* Extracted Declarations */}
        <section>
          <h3 className="text-xl font-bold border-b border-slate-200 pb-2 mb-4">Extracted Declarations</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-4 py-3 font-semibold border-b border-slate-200">Declaration</th>
                  <th className="px-4 py-3 font-semibold border-b border-slate-200">Extracted Evidence</th>
                  <th className="px-4 py-3 font-semibold border-b border-slate-200">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {report.extractedData && Object.entries(report.extractedData).map(([key, field]: [string, any]) => {
                  if (!field) return null;
                  const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
                  return (
                    <tr key={key}>
                      <td className="px-4 py-3 font-medium text-slate-700">{formattedKey}</td>
                      <td className="px-4 py-3 font-mono text-xs max-w-[200px] truncate" title={field.evidence || field.value}>
                         {field.present ? (field.evidence || field.value || "Present") : "Not reliably visible"}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${field.present ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                          {field.present ? 'Extracted' : 'Not Visible'}
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Applicable Regulatory Framework */}
        <section>
          <h3 className="text-xl font-bold border-b border-slate-200 pb-2 mb-4">Applicable Regulatory Framework</h3>
          {report.regulatoryAnalysis?.applicableRegulations && report.regulatoryAnalysis.applicableRegulations.length > 0 ? (
            <ul className="space-y-3">
              {report.regulatoryAnalysis.applicableRegulations.map((reg, idx) => (
                <li key={idx} className="flex items-start gap-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <ShieldCheck className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-semibold">{reg}</div>
                    <div className="text-xs text-slate-500 mt-1">Automatically selected based on AI category detection ({report.productIdentity?.category}).</div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-slate-500 italic">No applicable regulations determined.</div>
          )}
        </section>

        {/* Regulatory Requirement Analysis */}
        <section>
          <h3 className="text-xl font-bold border-b border-slate-200 pb-2 mb-6">Regulatory Requirement Analysis</h3>
          <div className="space-y-8">
            {report.regulatoryAnalysis?.evaluations.map((evalRecord, idx) => {
              
              let badgeColor = "bg-slate-100 text-slate-600";
              if (evalRecord.status === 'PASS') badgeColor = "bg-emerald-100 text-emerald-800";
              else if (evalRecord.status === 'REVIEW_REQUIRED') badgeColor = "bg-amber-100 text-amber-800";
              else if (evalRecord.status === 'POTENTIAL_ISSUE') badgeColor = "bg-red-100 text-red-800";

              return (
                <div key={idx} className="border border-slate-200 rounded-xl overflow-hidden print:break-inside-avoid">
                  <div className="bg-slate-50 px-4 py-3 border-b border-slate-200 flex justify-between items-center">
                    <h4 className="font-bold">{evalRecord.requirement}</h4>
                    <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide ${badgeColor}`}>
                      {evalRecord.status.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="p-4 space-y-4 text-sm">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="md:col-span-1 text-slate-500 font-medium">Applicability:</div>
                      <div className="md:col-span-3">{evalRecord.status === 'NOT_APPLICABLE' ? 'Not Applicable' : 'Applicable'}</div>
                    </div>
                    
                    {evalRecord.status !== 'NOT_APPLICABLE' && (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div className="md:col-span-1 text-slate-500 font-medium">Evidence:</div>
                          <div className="md:col-span-3 font-mono text-xs bg-slate-50 p-2 rounded border border-slate-100">
                            {evalRecord.evidence ? `"${evalRecord.evidence}"` : "Not reliably visible in supplied image"}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div className="md:col-span-1 text-slate-500 font-medium">Explanation:</div>
                          <div className="md:col-span-3 text-slate-700">{evalRecord.explanation}</div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div className="md:col-span-1 text-slate-500 font-medium">Source:</div>
                          <div className="md:col-span-3 text-slate-600 text-xs">{evalRecord.source}</div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Historical Product Comparison */}
        {report.historicalComparison && (
          <section className="print:break-inside-avoid">
            <h3 className="text-xl font-bold border-b border-slate-200 pb-2 mb-4">Historical Product Comparison</h3>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
              <div className="flex items-start gap-3 mb-4 text-amber-800">
                <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold">Potential Quantity Reduction Detected</h4>
                  <p className="text-sm mt-1">Verify product variant, packaging change and applicable requirements.</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="bg-white rounded-lg p-4 border border-amber-100">
                  <div className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-2">Previous Inspection</div>
                  <div className="text-[10px] text-slate-400 mb-2">{new Date(report.historicalComparison.previousDate).toLocaleDateString()}</div>
                  <div className="font-medium">Quantity: {report.historicalComparison.previousQuantity}</div>
                  <div className="font-medium">MRP: {report.historicalComparison.previousMrp || 'N/A'}</div>
                </div>
                <div className="bg-white rounded-lg p-4 border border-amber-100">
                  <div className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-2">Current Inspection</div>
                  <div className="text-[10px] text-slate-400 mb-2">{new Date(report.date).toLocaleDateString()}</div>
                  <div className="font-medium">Quantity: {report.historicalComparison.currentQuantity}</div>
                  <div className="font-medium">MRP: {report.historicalComparison.currentMrp || 'N/A'}</div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Why this result was assigned */}
        <section className="bg-slate-50 rounded-xl p-6 border border-slate-200 print:break-inside-avoid">
           <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
             <Info className="w-5 h-5 text-blue-600" />
             Why this result was assigned
           </h3>
           <div className="space-y-2 mb-4 text-sm font-medium">
             <div className="flex items-center gap-2">
               <span className="text-emerald-600">✓</span> {passedCount} requirements passed
             </div>
             <div className="flex items-center gap-2">
               <span className="text-red-600">{issueCount > 0 ? '✕' : '✓'}</span> {issueCount} potential issues
             </div>
             <div className="flex items-center gap-2">
               <span className="text-amber-600">{reviewCount > 0 ? '⚠' : '✓'}</span> {reviewCount} requirements require visual verification
             </div>
           </div>
           <div className="pt-4 border-t border-slate-200">
             <div className="text-sm">
               Therefore: <strong className="uppercase">{statusText}</strong>
               <p className="mt-1 text-slate-600">{statusDesc}</p>
             </div>
           </div>
        </section>

        {/* Disclaimer */}
        <section className="text-xs text-slate-500 text-justify border-t border-slate-200 pt-6 mt-12 print:break-inside-avoid">
          <strong>DISCLAIMER:</strong> FMCG-AuditPro provides preliminary, evidence-based packaging compliance screening. Results depend on the supplied image, extracted evidence, encoded regulatory requirements and rule applicability. REVIEW_REQUIRED indicates insufficient or uncertain evidence and does not itself establish non-compliance. Final legal/regulatory determination requires appropriate human verification.
        </section>
      </div>
    </div>
  );
}
