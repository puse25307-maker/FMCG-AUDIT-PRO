export interface ExtractedField {
  value: string | number | null;
  normalizedValue?: string | number | null;
  unit?: string | null;
  currency?: string | null;
  present: boolean;
  confidence: number;
  evidence: string | null;
}

export interface ExtractedData {
  manufacturerDetails?: ExtractedField;
  packerDetails?: ExtractedField;
  importerDetails?: ExtractedField;
  countryOfOrigin?: ExtractedField;
  commonGenericName?: ExtractedField;
  netQuantity?: ExtractedField;
  quantityUnit?: ExtractedField;
  mrp?: ExtractedField;
  currency?: ExtractedField;
  batchLot?: ExtractedField;
  manufacturingDate?: ExtractedField;
  packingDate?: ExtractedField;
  bestBefore?: ExtractedField;
  useBy?: ExtractedField;
  expiry?: ExtractedField;
  consumerCare?: ExtractedField;
  unitSalePrice?: ExtractedField;
  dimensions?: ExtractedField;
  modelNumber?: ExtractedField;
  otherVisibleDeclarations?: ExtractedField;
  [key: string]: ExtractedField | undefined;
}

export interface RuleEvaluation {
  ruleId: string;
  requirement: string;
  status: 'PASS' | 'MISSING' | 'NOT_APPLICABLE' | 'UNCERTAIN' | 'REVIEW_REQUIRED' | 'POTENTIAL_ISSUE';
  evidence: string | null;
  confidence: number;
  source: string;
  explanation: string;
}

export interface RegulatoryAnalysis {
  applicableRegulations: string[];
  evaluations: RuleEvaluation[];
}

export interface InspectionRecord {
  id: string;
  date: string;
  status: 'PASS' | 'POTENTIAL_ISSUE' | 'REVIEW_REQUIRED';
  productIdentity?: {
    brand?: string;
    productName?: string;
    variant?: string;
    category?: string;
    subcategory?: string;
    confidence?: number;
  };
  imageQuality?: {
    status: 'GOOD' | 'FAIR' | 'POOR';
    confidence: number;
  };
  imageUrl?: string;
  extractedData?: ExtractedData;
  regulatoryAnalysis?: RegulatoryAnalysis;
  historicalComparison?: {
    previousQuantity: string | number;
    currentQuantity: string | number;
    previousMrp?: string | number;
    currentMrp?: string | number;
    previousDate: string;
    quantityChange: number;
  } | null;
  message?: string;
  issueCount?: number;
  reviewStatus?: string;
}
