const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const replacement = `
import fs from "fs";

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// --- PERSISTENT DATABASE ---
const DATA_FILE = path.join(process.cwd(), 'data.json');

let db = {
  inspections: [],
  reports: [],
  notifications: []
};

if (fs.existsSync(DATA_FILE)) {
  try {
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    db = { ...db, ...parsed };
    if (!db.inspections) db.inspections = [];
    if (!db.reports) db.reports = [];
    if (!db.notifications) db.notifications = [];
  } catch (err) {
    console.error("Error reading data.json:", err);
  }
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error("Error saving data.json:", err);
  }
}

// Proxy arrays so existing code (push/unshift) automatically triggers saveData
const createProxy = (arr, type) => {
  return new Proxy(arr, {
    set(target, prop, value) {
      target[prop] = value;
      saveData();
      return true;
    }
  });
};

let inspections = createProxy(db.inspections, 'inspections');
let reports = createProxy(db.reports, 'reports');
`;

content = content.replace("app.use(express.json());\n\n// --- MOCK DATABASE ---\n// In a real app, this would be a real database.\nlet inspections: any[] = [];\nlet reports: any[] = [];", replacement);

// also fix notifications
content = content.replace("let notifications: AppNotification[] = [];", `
let notifications = createProxy(db.notifications, 'notifications');
`);

fs.writeFileSync('server.ts', content);
