let saves = 0;
function saveData() { saves++; }
let arr = [1, 2];
const proxy = new Proxy(arr, {
  set(target, prop, value) {
    let key = Number(prop);
    if (isNaN(key)) key = prop;
    target[key] = value;
    saveData();
    return true;
  }
});
proxy.unshift(0);
console.log(arr, saves);
