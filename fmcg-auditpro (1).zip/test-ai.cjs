const { GoogleGenAI } = require('@google/genai');
const ai = new GoogleGenAI();
ai.models.list().then(res => console.log(res.map(m => m.name).join('\n'))).catch(err => { console.error(err); });
