const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

content = content.replace("const newId = `ins-${Date.now()}`;", "");
content = content.replace("let imageUrl = '';", "const newId = `ins-${Date.now()}`;\n    let imageUrl = '';");

fs.writeFileSync('server.ts', content);
