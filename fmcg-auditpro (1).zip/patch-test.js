const css = "oklch(0.5 0.1 200)";
console.log(css.replace(/oklch\([^)]+\)/g, 'rgb(128, 128, 128)'));
