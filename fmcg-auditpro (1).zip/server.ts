import express from "express";
import path from "path";
import multer from "multer";
import { createServer as createViteServer } from "vite";
import { RuleEngine } from "./ruleEngine";

const app = express();
const PORT = 3000;

// Configure multer for file uploads in memory
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});


import fs from "fs";

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));



const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR));

// --- PERSISTENT DATABASE ---

const DATA_FILE = path.join(process.cwd(), 'data.json');

let db: {
  inspections: any[];
  reports: any[];
  notifications: AppNotification[];
} = {
  inspections: [],
  reports: [],
  notifications: []
};

if (fs.existsSync(DATA_FILE)) {
  try {
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    db = { ...db, ...parsed };
    if (!db.inspections) db.inspections = [];
    if (!db.reports) db.reports = [];
    if (!db.notifications) db.notifications = [];
  } catch (err) {
    console.error("Error reading data.json:", err);
  }
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error("Error saving data.json:", err);
  }
}

// Proxy arrays so existing code (push/unshift) automatically triggers saveData
const createProxy = <T extends any[]>(arr: T): T => {
  return new Proxy(arr, {
    set(target, prop, value) {
      target[Number(prop) || prop as any] = value;
      saveData();
      return true;
    }
  });
};

let inspections = createProxy(db.inspections);
let reports = createProxy(db.reports);



// --- API ROUTES ---

// 1. GET /api/inspections
app.get("/api/inspections", (req, res) => {
  res.json(inspections);
});

// 2. GET /api/inspections/:id
app.get("/api/inspections/:id", (req, res) => {
  const { id } = req.params;
  const inspection = inspections.find((i) => i.id === id);
  if (!inspection) {
    return res.status(404).json({ error: "Inspection not found" });
  }
  res.json(inspection);
});

// 3. GET /api/reports
app.get("/api/reports", (req, res) => {
  res.json(reports);
});

interface AppNotification {
  id: string;
  inspectionId: string;
  type: 'REVIEW_REQUIRED' | 'POTENTIAL_ISSUE';
  title: string;
  message: string;
  createdAt: string;
  read: boolean;
}


let notifications = createProxy(db.notifications);


// 4. GET /api/notifications
app.get("/api/notifications", (req, res) => {
  res.json(notifications);
});

app.post("/api/notifications/:id/read", (req, res) => {
  const notif = notifications.find(n => n.id === req.params.id);
  if (notif) notif.read = true;
  res.json({ success: true });
});

app.post("/api/notifications/read-all", (req, res) => {
  notifications.forEach(n => n.read = true);
  res.json({ success: true });
});

// 5. POST /api/analyze
app.post("/api/analyze", upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No image provided" });
    }

    

    // Persist Image locally instead of base64
    const newId = `ins-${Date.now()}`;
    let imageUrl = '';
    try {
      const ext = req.file.mimetype.split('/')[1] || 'jpg';
      const filename = `${newId}.${ext}`;
      const filepath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filepath, req.file.buffer);
      imageUrl = `/uploads/${filename}`;
    } catch (err) {
      console.error("Failed to save image to disk:", err);
      // Fallback to base64 if disk write fails
      imageUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    }

    if (!process.env.GEMINI_API_KEY) {
      console.error("[API/Analyze] GEMINI_API_KEY is not configured.");
      return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server." });
    }

    console.log(`[API/Analyze] Request reached endpoint.`);
    console.log(`[API/Analyze] File received: ${req.file.originalname}`);
    console.log(`[API/Analyze] MIME type: ${req.file.mimetype}`);
    console.log(`[API/Analyze] File size: ${req.file.size} bytes`);

    const { GoogleGenAI, Type } = await import("@google/genai");
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    const extractedFieldSchema = {
      type: Type.OBJECT,
      properties: {
        value: { type: Type.STRING, nullable: true },
        normalizedValue: { type: Type.STRING, nullable: true },
        unit: { type: Type.STRING, nullable: true },
        currency: { type: Type.STRING, nullable: true },
        present: { type: Type.BOOLEAN },
        confidence: { type: Type.NUMBER },
        evidence: { type: Type.STRING, nullable: true }
      },
      required: ["present", "confidence"]
    };

    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        success: { type: Type.BOOLEAN },
        inspection: {
          type: Type.OBJECT,
          properties: {
            productIdentity: {
              type: Type.OBJECT,
              properties: {
                brand: { type: Type.STRING, nullable: true },
                productName: { type: Type.STRING, nullable: true },
                variant: { type: Type.STRING, nullable: true },
                category: { type: Type.STRING, enum: ["FOOD", "COSMETICS_PERSONAL_CARE", "HOUSEHOLD_CLEANING", "BEVERAGE", "ELECTRONICS", "OTHER_PREPACKAGED_COMMODITY", "UNKNOWN"] },
                subcategory: { type: Type.STRING, nullable: true },
                confidence: { type: Type.NUMBER }
              },
              required: ["category", "confidence"]
            },
            imageQuality: {
              type: Type.OBJECT,
              properties: {
                status: { type: Type.STRING, enum: ["GOOD", "FAIR", "POOR"] },
                confidence: { type: Type.NUMBER }
              },
              required: ["status", "confidence"]
            },
            extractedData: {
              type: Type.OBJECT,
              properties: {
                manufacturerDetails: extractedFieldSchema,
                packerDetails: extractedFieldSchema,
                importerDetails: extractedFieldSchema,
                countryOfOrigin: extractedFieldSchema,
                commonGenericName: extractedFieldSchema,
                netQuantity: extractedFieldSchema,
                quantityUnit: extractedFieldSchema,
                mrp: extractedFieldSchema,
                currency: extractedFieldSchema,
                batchLot: extractedFieldSchema,
                manufacturingDate: extractedFieldSchema,
                packingDate: extractedFieldSchema,
                bestBefore: extractedFieldSchema,
                useBy: extractedFieldSchema,
                expiry: extractedFieldSchema,
                consumerCare: extractedFieldSchema,
                unitSalePrice: extractedFieldSchema,
                dimensions: extractedFieldSchema,
                modelNumber: extractedFieldSchema,
                otherVisibleDeclarations: extractedFieldSchema
              }
            }
          },
          required: ["productIdentity", "imageQuality", "extractedData"]
        }
      },
      required: ["success", "inspection"]
    };

    const AI_MODEL = "gemini-3.6-flash";

    const prompt = `
You are an expert FMCG and packaged commodities compliance analyst.
Analyze the provided product package image.

1. PRODUCT IDENTIFICATION
Identify the product category carefully. Use "UNKNOWN" if you are not sure.
Available categories: FOOD, COSMETICS_PERSONAL_CARE, HOUSEHOLD_CLEANING, BEVERAGE, ELECTRONICS, OTHER_PREPACKAGED_COMMODITY, UNKNOWN.

2. IMAGE QUALITY
Assess if the image is readable enough to extract declarations. (GOOD, FAIR, POOR).
If POOR, you may leave most extracted fields as present: false.

3. DECLARATION EXTRACTION
Extract text exactly as it appears for evidence.
Normalize quantities (e.g., 60g -> 60 g) and prices (Rs. 10 -> 10 INR).
If a field is not visible in the image, set present: false and value: null.
DO NOT hallucinate or guess fields not visible in the image.

NOTE: Do not make legal compliance judgments yet. Just extract the facts.
`;

    // Retry logic with exponential backoff
    const MAX_RETRIES = 3;
    let attempt = 0;
    let response;

    while (attempt < MAX_RETRIES) {
      try {
        console.log(`[AI Analysis] Starting attempt ${attempt + 1} with model ${AI_MODEL}...`);
        response = await ai.models.generateContent({
          model: AI_MODEL,
          contents: { 
            parts: [
              { text: prompt },
              {
                inlineData: {
                  data: req.file.buffer.toString("base64"),
                  mimeType: req.file.mimetype,
                }
              }
            ]
          },
          config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema,
          }
        });
        console.log(`[AI Analysis] Attempt ${attempt + 1} succeeded.`);
        break; // Success, exit retry loop
      } catch (err: any) {
        attempt++;
        const errorMessage = err.message || "";
        console.error(`[AI Analysis] Attempt ${attempt} failed:`, errorMessage);

        // Don't retry on 429 Quota Exhausted or 400 Bad Request
        if (errorMessage.includes("429") || errorMessage.includes("RESOURCE_EXHAUSTED")) {
          throw new Error("AI analysis quota exceeded or rate limited. Please try again later.");
        }
        if (errorMessage.includes("400") || errorMessage.includes("INVALID_ARGUMENT")) {
          throw new Error("The image format or request was invalid.");
        }

        if (attempt >= MAX_RETRIES) {
          throw new Error(`AI service temporarily unavailable after ${MAX_RETRIES} attempts. Please try again later.`);
        }
        
        // Exponential backoff for 503/500 errors
        const backoffMs = Math.pow(2, attempt) * 1000;
        console.log(`[AI Analysis] Retrying in ${backoffMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, backoffMs));
      }
    }

    if (!response) {
      throw new Error("Failed to receive a response from the AI service.");
    }

    console.log(`[API/Analyze] AI response received.`);
    
    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response text from AI");
    }

    console.log(`[API/Analyze] AI parsing started.`);
    const aiData = JSON.parse(resultText);
    console.log(`[API/Analyze] AI parsing succeeded.`);

    
    
    const category = aiData.inspection.productIdentity.category;
    const imageQuality = aiData.inspection.imageQuality.status;
    const extractedData = aiData.inspection.extractedData;

    console.log(`[API/Analyze] Running Rule Engine...`);
    const applicableRegulations = RuleEngine.getApplicableRegulations(category);
    let evaluations = RuleEngine.evaluate(extractedData, category, imageQuality);
    
    // 11. REPORT CONSISTENCY VALIDATOR
    const isConsistent = RuleEngine.validateConsistency(evaluations, extractedData);
    if (!isConsistent) {
        // Force REVIEW_REQUIRED on all passes if consistency fails
        evaluations = evaluations.map(e => ({
            ...e,
            status: e.status === 'NOT_APPLICABLE' ? 'NOT_APPLICABLE' : 'REVIEW_REQUIRED',
            explanation: "Evidence consistency could not be reliably established."
        }));
    }
    
    let finalStatus = RuleEngine.calculateOverallStatus(evaluations);
    let message = "Requirements satisfied based on available evidence.";

    if (imageQuality === 'POOR') {
        message = "Image quality is too poor for confident extraction. Please capture a clearer image, move closer to the declaration, or reduce glare.";
    } else if (category === 'UNKNOWN') {
        message = "Product category could not be confidently determined from the image.";
        finalStatus = 'REVIEW_REQUIRED';
    } else if (finalStatus === 'POTENTIAL_ISSUE') {
        message = "Potential compliance issue detected. Human verification recommended.";
    } else if (finalStatus === 'REVIEW_REQUIRED') {
        message = "Insufficient or uncertain evidence for a reliable determination.";
    } else {
        message = "All currently applicable encoded requirements were satisfied based on the available package evidence.";
    }

    // Historical Comparison Logic
    let historicalComparison = null;
    if (aiData.inspection.productIdentity.brand && aiData.inspection.productIdentity.productName && aiData.inspection.productIdentity.category !== 'UNKNOWN') {
      const brand = aiData.inspection.productIdentity.brand.toLowerCase();
      const productName = aiData.inspection.productIdentity.productName.toLowerCase();
      
      const previousInspections = inspections.filter(i => 
        i.productIdentity?.brand?.toLowerCase() === brand &&
        i.productIdentity?.productName?.toLowerCase() === productName &&
        i.extractedData
      );

      if (previousInspections.length > 0) {
        const prev = previousInspections[0]; // Most recent since we unshift
        const prevQuantity = prev.extractedData?.netQuantity?.value;
        const currQuantity = extractedData.netQuantity?.value;
        const prevMrp = prev.extractedData?.mrp?.value;
        const currMrp = extractedData.mrp?.value;

        if (prevQuantity && currQuantity && prevQuantity !== currQuantity) {
          historicalComparison = {
            previousQuantity: prevQuantity,
            currentQuantity: currQuantity,
            previousMrp: prevMrp,
            currentMrp: currMrp,
            previousDate: prev.date,
            quantityChange: parseFloat(currQuantity) - parseFloat(prevQuantity)
          };
        }
      }
    }

    const newInspection = {
      id: newId,
      date: new Date().toISOString(),
      status: finalStatus,
      productIdentity: aiData.inspection.productIdentity,
      imageQuality: aiData.inspection.imageQuality,
      imageUrl: imageUrl,
      extractedData: extractedData,
      regulatoryAnalysis: {
        applicableRegulations,
        evaluations
      },
      historicalComparison: historicalComparison,
      message: message,
      issueCount: evaluations.filter(e => e.status === 'MISSING' || e.status === 'POTENTIAL_ISSUE').length,
      reviewStatus: "none"
    };

    inspections.unshift(newInspection);

    if (finalStatus === 'REVIEW_REQUIRED' || finalStatus === 'POTENTIAL_ISSUE') {
      notifications.unshift({
        id: `notif-${Date.now()}`,
        inspectionId: newId,
        type: finalStatus,
        title: finalStatus === 'REVIEW_REQUIRED' ? 'Review Required' : 'Potential Issue',
        message: `${finalStatus === 'REVIEW_REQUIRED' ? 'Review required' : 'Potential compliance issue detected'} for ${aiData.inspection.productIdentity?.brand || 'Product'} ${aiData.inspection.productIdentity?.productName || ''}`.trim(),
        createdAt: new Date().toISOString(),
        read: false
      });
    }

    return res.json({ 
      success: true, 
      message: message,
      inspectionId: newId,
      inspection: newInspection
    });
  } catch (error: any) {
    console.error("Error processing image:", error);
    res.status(500).json({ 
      success: false,
      code: "ANALYSIS_FAILED",
      error: error.message || "Failed to process image",
      stack: error.stack
    });
  }
});


// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
