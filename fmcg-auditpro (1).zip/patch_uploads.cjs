const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

const replacement1 = `
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR));

// --- PERSISTENT DATABASE ---
`;
content = content.replace("// --- PERSISTENT DATABASE ---", replacement1);

const analyzeReplacement = `
    const newId = \`ins-\${Date.now()}\`;

    // Persist Image locally instead of base64
    let imageUrl = '';
    try {
      const ext = req.file.mimetype.split('/')[1] || 'jpg';
      const filename = \`\${newId}.\${ext}\`;
      const filepath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filepath, req.file.buffer);
      imageUrl = \`/uploads/\${filename}\`;
    } catch (err) {
      console.error("Failed to save image to disk:", err);
      // Fallback to base64 if disk write fails
      imageUrl = \`data:\${req.file.mimetype};base64,\${req.file.buffer.toString('base64')}\`;
    }
`;

content = content.replace(/const imageUrl = `data:\$\{req\.file\.mimetype\};base64,\$\{req\.file\.buffer\.toString\('base64'\)\}`;/, analyzeReplacement.trim());
content = content.replace(/const newId = `ins-\$\{Date\.now\(\)\}`;/, '');

fs.writeFileSync('server.ts', content);
